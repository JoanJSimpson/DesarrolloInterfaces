<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Ejercicio 8</title>
    </head>
    <body>
        <h1> FOTOS </h1>
        <?php
        // Ejercicio 4.8: ídem al anterior, pero que muestre las fotos en 100x100 y que al pulsar abra la foto 
        // entera. Compruebe que sólo muestra fotos con extensión .jpg, .png, bmp o .gif (haga una función 
        // que lo compruebe usando las expresiones regulares como aparecen en el manual).
        
        $ruta = "fotos/";  //indicamos ruta
        $fileName = opendir ($ruta); //Abrir archivos
        $contador =1;
        $patron = "%\.(gif|jpe?g|png)$%i";
        
        while ($file = readdir($fileName)){
            if (preg_match($patron, $file) == 1){
                //echo preg_match($patron, $file) == 1 ? 'valido' : 'invalido';
                print '<a href =' .$ruta.$file. '> <img src='.$ruta.$file.' width="100" height="100" /> </a>';
                $contador++;
            }
            if ($contador>=5){
                print "<br>";
                $contador=1;
            }
        }
        ?>
    </body>
</html>
