<?php
//Ejercicio 4.1: Concatena dos cadenas con el operador punto (.) e imprimir su resultado
$cadena = "Valencia";
$cadena .= ".C.F.";
print "<p>$cadena</p>\n";
?>