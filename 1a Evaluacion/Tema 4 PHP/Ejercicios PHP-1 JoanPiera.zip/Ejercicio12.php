<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
         <?php
        //Ejercicio 4.12: Imprimir los valores del vector asociativo siguiente usando la estructura de
        //control for each :  
        //$v[1]=90;
        //$v[30]=7;
        //$v['e']=99;
        //$v['hola']=43;
        $v[1]=90;
        $v[30]=7;
        $v['e']=99;
        $v['hola']=43;
        foreach($v as $i => $value){
            print "El elemento con indice: $i vale: $value<br>";
        }
         
        ?>
    </body>
</html>
