<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Ejercicio 10</title>
    </head>
    <body>
        <h1> FOTOS </h1>
        <?php
        //Ejercicio 4.10: ídem al anterior, pero que si no existe la miniatura de una foto debe de crearla. 
        //Para generar la miniatura se usa el programa convert (hay que invocarlo en línea de comandos 
        //desde PHP son la función system).
        print "<h1>Galeria de imagenes</h1>";
        function valida_foto($fotos){
          $rdo=0;
          if (ereg("[Jj][Pp][Gg]$", $fotos)){
              $rdo=1;
          }
          if (ereg("[Gg][Ii][Ff]$", $fotos)){
              $rdo=1;
          }
          if (ereg("[Pp][Nn][Gg]$", $fotos)){
              $rdo=1;
          }
          if (ereg("[Bb][Mm][Pp]$", $fotos)){
              $rdo=1;
          }
          return $rdo;
        }
        
        function crea_tumbs($foto){
            if (!is_dir('fotos/tumbs')){
              mkdir ('fotos/tumbs', 0777, true);
              chmod ("fotos/tumbs", 0777);
            }
            if (!is_file('fotos/tumbs/MINI-'.$foto))
                    system ("convert -sample 40x40 /fotos/".$foto." /fotos/tumbs/MINI-".$foto);
        }
            print "<table border=1>";
            $puntero = opendir('fotos');
            $i=1;
            while (false !== ($foto = readdir($puntero))){
                if ($foto!="." && $foto!=".." && valida_foto($foto)){
                    crea_tumbs($foto);
                    if ($i==1){
                        print "<tr>";
                    }
                    print '<td><a href=fotos/tumbs/MINI-'.$foto.'>';
                    print '<img src=fotos/'.$foto.' width=100 height=100></img>';
                    print "</a></td>";
                    if ($i==4){
                        print "</tr>"; 
                        $i=0;
                    }
                $i++;
                } 
           }
           closedir($puntero);
        
        
        print "</table>";
        ?>
    </body>
</html>