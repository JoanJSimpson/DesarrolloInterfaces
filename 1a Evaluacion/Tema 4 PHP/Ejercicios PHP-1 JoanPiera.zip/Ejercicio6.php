<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Ejercicio 4.6</title>
    </head>
    <body>
        <?php
//Ejercicio 4.6: mostrar una tabla de 4 por 4 que muestre las primeras 4 potencias de los números del uno 1 al 4 
//(hacer una función que las calcule invocando la función pow). En PHP las funciones hay que definirlas antes 
//de invocarlas. Los parámetros se indican con su nombre ($cantidad) si son por valor y antecedidos 
//de & (&$cantidad) si son por referencia.
        function potencia($base, $potencia){
            print pow($base, $potencia);
        }
        
        
        print "<table border=1>";
        for ($i=1; $i<=4;$i++){
            print "<tr>";
            for ($j=1; $j<=4; $j++){
                print "<td>";
                potencia($i, $j);
                print "</td>";
            }
            print "</td>";
        }
        print "</table>";
        ?>
    </body>
</html>
