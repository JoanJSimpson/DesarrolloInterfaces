<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Ejercicio 9</title>
    </head>
    <body>
        <h1> FOTOS </h1>
        <?php
        //Ejercicio 4.9: ídem al anterior, pero que por cada foto tenga una miniatura. 
        //Para la foto playa.jpg la miniatura será MINI­playa.jpg
        
        $ruta = "fotos/";  //indicamos ruta
        $rutaTumbs = "Tumbs/"; //ruta Miniaturas
        $fileName = opendir ($ruta); //Abrir archivos
        $contador =1;
        $patron = "%\.(gif|jpe?g|png)$%i";
        $mini = "MINI-";
        
        while ($file = readdir($fileName)){
            if (preg_match($patron, $file) == 1){
                //echo preg_match($patron, $file) == 1 ? 'valido' : 'invalido';
                print '<a href =' .$ruta.$file. '> <img src='.$rutaTumbs.$mini.$file.' width="100" height="100" /> </a>';
                $contador++;
            }
            if ($contador>=5){
                print "<br>";
                $contador=1;
            }
        }
        ?>
    </body>
</html>
