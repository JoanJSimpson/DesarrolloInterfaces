<?php
//Ejercicio 4.4: Mostrar en pantalla una tabla de 10 por 10 con los números del 1 al 100
	print "<table>";
	$cont = 1;

	for ($i = 1; $i<=10; $i++){
		print "<tr>";

		for ($j=1; $j<=10; $j++){
			print "<td>" . $cont . "</td>";
			$cont++;
		}

		print "</tr>";
	}

	print "</table>";
?>