<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Ejercicio 11</title>
    </head>
    <body>
    
        <?php
        //Ejercicio 4.11: Vectores. Almacenar en un vector los 10 primeros número pares. 
        //Imprimirlos cada uno en una línea (recuerde que el salto de línea en HTML es < BR>) .
        for ($i=0; $i<10; $i++){
            $vector[$i] = ($i+1)* 2;
        }
        for ($i=0; $i<10; $i++){
            print "$vector[$i]<br>";
            
        }
       ?>

    </body>
</html>
