<html>
<head>
	<title>Ejercicio 4.5 Joan Piera</title>
	<style>
		tr:nth-child(odd){
			background:grey;
		}
	</style>
</head>
<body>
	<?php
	//Ejercicio 4.5: ídem a 4.4 anterior, pero colorear las filas alternando gris y blanco. Además, el tamaño será una constante: define(TAM, 10)
		define("TAM",10);
		print "<table border=1>";
		$cont = 1;

		for ($i = 1; $i<=10; $i++){
			print "<tr>";
			for ($j=1; $j<=TAM; $j++){
				print "<td>" . $cont . "</td>";
				$cont++;
			}

			print "</tr>";
		}

		print "</table>";

		?>
</body>
</html>