<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Ejercicio 4.7</title>
    </head>
    <body>
        <?php
        // Ejercicio 4.7: hacer un programa que muestre en una tabla de 4 columnas todas las imágenes de el 
        // directorio "fotos". Para ello consulte el manual (en concreto la referencia de funciones de directorios).
        // Suponga que en el directorio sólo existen fotos.
        $ruta = "fotos/";  //indicamos ruta
        $fileName = opendir ($ruta); //Abrir archivos
        $contador =1;
        while ($file = readdir($fileName)){
            if ($file !="." && $file !=".."){
                 print '<img src='.$ruta.$file.' width="200" height="200" />';
                 $contador++;
            }
            if ($contador>=5){
                print "<br>";
                $contador=1;
            }
        }
        ?>
    </body>
</html>
