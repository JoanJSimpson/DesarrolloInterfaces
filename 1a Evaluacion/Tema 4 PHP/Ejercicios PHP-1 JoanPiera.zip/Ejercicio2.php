<?php
//Ejercicio 4.2: Hacer un programa que sume dos variables que almacenan dos números distintos.
$a =25;
$b = 5;
$suma = $a+$b;
print "Si a= $a y b= $b, la suma sera= $suma";
?>