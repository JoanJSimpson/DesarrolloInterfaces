<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8" />
        <title>Examen Joan Piera Simó</title>
        <link href="examen.css" rel="stylesheet" type="text/css"/>
    </head>
    
    <body>
        <div id='contact'><h1>Contador de días (Resultado 1)</h1>
            <?php
            
            //funcion recogida de mclibre
            function recoger($variable){
                $devuelta = (isset($_REQUEST[$variable]))? trim(htmlspecialchars($_REQUEST[$variable], ENT_QUOTES, "UTF-8")): "";
                return $devuelta;
            }
            //creamos las variables
            $todoBien = false;
            //numero recogido de la pantalla anterior
            $numeroRecogido   = recoger("numerosemanas");
            //valores maximos y minimos
            $valorMinimo   = 1;
            $valorMaximo   = 20;
            //si el numero recogido esta en blanco
            if ($numeroRecogido == "") {
                echo "<p>No ha escrito el número de semanas.</p>";
            //si el numero recogido no es un número    
            } elseif (!is_numeric($numeroRecogido)) {
                echo "<p>Los datos introducidos no son un número.</p>";
            //si el numero recogido no es un entero posivo    
            } elseif (!ctype_digit($numeroRecogido)) {
                echo "<p>Los datos introducidos no son un número entero</p>";
            //si el numero recogido no esta entre el minimo y el maximo    
            } elseif ($numeroRecogido < $valorMinimo || $numeroRecogido > $valorMaximo) {
                echo "<p>El número de semanas introducido debe estar entre $valorMinimo y $valorMaximo.</p>";
            //si no hay ninguno de los errores anteriores es que esta todo bien    
            } else {
                $todoBien = true;
                
            }
            //si esta todo bien se crea el formulario con su tabla
            if ($todoBien) {
                echo "<form action='contador_dias_3.php' method='post'>";
                echo "  <div id='contact2'><p align='center'> Marque las casillas de verificación que quiera y contaré cuántas ha marcado.</p>";
                echo "  <div align='center'><table>";
                echo "    <tbody style='text-align: center' >";
                echo "      <tr>";
                echo "        <th>Semana</th>";
                echo "        <th>Lunes</th>";
                echo "        <th>Martes</th>";
                echo "        <th>Miércoles</th>";
                echo "        <th>Jueves</th>";
                echo "        <th>Viernes</th>";
                echo "        <th>Sábado</th>";
                echo "        <th>Domingo</th>";
                echo "      </tr>";
                for ($i = 1; $i <= $numeroRecogido; $i++) {
                    echo "      <tr>";
                    echo "        <th>$i</th>";
                    for ($j = 1; $j <= 7; $j++) {
                        echo "  <td><input type='checkbox' name='checkeadas[$i][$j]'/></td>";
                    }
                    echo "      </tr>";
                }
                echo "    </tbody>";
                echo "  </table></div>";
                //creamos los botones enviar y borrar
                echo "  <p align='center'><input type='submit' value='Convertir' />"; 
                echo "    <input type='reset' value='Borrar' name='Reset' /></p>";
                //enviamos tambien el numero de semanas recogido de la pantalla anterior
                echo "  <p><input type='hidden' name='numerosemanas' value='$numeroRecogido' /></p>";
                echo "</form></div>";
                
            }
            ?>
        <!-- Creamos el enlace para ir al formulario inicial-->
        <p><a href="contador_dias_1.html">Volver al formulario inicial</a></p></div>
    </body>
</html>