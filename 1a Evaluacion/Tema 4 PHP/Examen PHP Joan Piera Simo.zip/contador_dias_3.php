<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8" />
        <title>Examen Joan Piera Simó</title>
        <link href="examen.css" rel="stylesheet" type="text/css" />
    </head>
    
    <body>
        <div id='contact'><h1>Contador de días (Resultado 2)</h1>
            <?php
            //funcion recogida de mclibre
            function recoger($variable){
                $devuelta = (isset($_REQUEST[$variable]))? trim(htmlspecialchars($_REQUEST[$variable], ENT_QUOTES, "UTF-8")): "";
                return $devuelta;
            }
            //funcion recogida de mclibre 
            function recogerMatriz($variable){
                $matrizDevuelta = array();
                if (isset($_REQUEST[$variable]) && is_array($_REQUEST[$variable])) {
                    foreach ($_REQUEST[$variable] as $indice => $fila) {
                        $indiceLimpio = trim(htmlspecialchars($indice, ENT_QUOTES, "UTF-8"));
                        if (is_array($fila)) {
                            foreach ($fila as $indice2 => $valor) {
                                $indiceFinal = trim(htmlspecialchars($indice2, ENT_QUOTES, "UTF-8"));
                                $valorFinal   = trim(htmlspecialchars($valor,   ENT_QUOTES, "UTF-8"));
                                $matrizDevuelta[$indiceLimpio][$indiceFinal] = $valorFinal;
                                
                            }   
                        }
                    }
                }
                return $matrizDevuelta;
            }
            //creamos las variables, las especificas para esta pantalla y las recogidas de la pantalla anterior
            //las de la pantalla anterior se recogen dentro de las funciones recoger y recogerMatriz
            $numeroRecogido = recoger("numerosemanas");
            $casillas = recogerMatriz("checkeadas");
            //COUNT_RECURSIVE es para contar un array multidimensional de forma recursiva
            $casillasMarcadas = count($casillas, COUNT_RECURSIVE) - count($casillas);
            //valores maximos y minimos
            $valorMinimo = 1;
            $valorMaximo = 20;
            $valorCheckeados = "on";
            //si no se ha marcado ninguna casilla
            if ($casillasMarcadas == 0) {
                echo "<div><p>No has marcado ninguna casilla.</p>";
                echo "<p align='center'><a href='contador_dias_2.php?numerosemanas=$numeroRecogido'>Volver al calendario</a></p></div>";
                
            //si se ha marcado alguna casilla    
            } else{
            
                echo "<div id='contact2'><p>En total ha marcado $casillasMarcadas días:</p>";
                echo "<ul>";
                for ($i = 1; $i <= $numeroRecogido; $i++) {
                    //si en esa semana no se ha marcado ninguna casilla
                    if (!isset($casillas[$i])) {
                        echo "  <li>En la semana $i no ha marcado ningun día.</li>";
                    //si en esa semana si que se ha marcado alguna casilla    
                    } else {
                        if (count($casillas[$i])>1) {
                            echo "  <li>En la semana $i ha marcado <strong>".count($casillas[$i])."</strong> días";
                        } else {
                            echo "  <li>En la semana $i ha marcado <strong>".count($casillas[$i])."</strong> día"; 
                        }
                        echo "</li>";
                        
                    }
                }
                echo "</ul>";
                //enlace para ir al calendario (pagina anterior)
                echo "<p align='center'><a href='contador_dias_2.php?numerosemanas=$numeroRecogido'>Volver al calendario</a></p></div>";
                
            }
            ?>
        <!-- Creamos el enlace para ir al formulario inicial-->
        <p><a href="contador_dias_1.html">Volver al formulario inicial</a></p></div>
    </body>
</html>